package co.edu.uniminuto.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import co.edu.uniminuto.entity.TypesUser;

public interface JpaTypesUser extends JpaRepository<TypesUser, Integer>{

}
